export class UserPayload {
    first_name: string;
    email: string;
    last_name: string;
    phone:string;
    age:number
  }