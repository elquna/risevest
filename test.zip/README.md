# Rise Test

To run the app, run the following in your terminal

ts-node src/index.ts

it runs in port 3000

#Requirements
Node 18 and above
NPM
Docker
Postgres

Steps
cd into whatever directory you want work from.
Run https://github.com/elquna/risevest.git then cd into the repo.
After cloning the project, run cp .env .env.example on your terminal to create a new .env file from the .env.example.
Run npm install to install all the dependencies.
Run ts-node src/index.ts the project in development mode.
